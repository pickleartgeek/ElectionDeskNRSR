const {chromium}=require('playwright');const SP=process.cwd();
const K=(process.argv[2]||'1').split(',').map(Number), N=+(process.argv[3]||40), EL=process.argv[4]||'nrsr2023';
(async()=>{const b=await chromium.launch();const pg=await (await b.newContext({viewport:{width:1400,height:900}})).newPage();
await pg.route(/fonts\.|wikipedia|wikidata|overpass/,r=>r.abort());
await pg.goto('file://'+SP+'/site/desk/index.html');await pg.waitForTimeout(3500);
const out=await pg.evaluate(async({K,N,EL})=>{
 const ST=window.__ED_STATE, U=window.__ED_UTILS, S=ST.state.sim;
 if(EL!==ST.state.electionId) ST.setElection(EL);
 ST.state.mode='simulator'; S.mergePD=false;
 const res={}; K.forEach(k=>res[k]={cov:{},n:{},brFirst:0,brBloc:0,nb:0,nf:0,byF:{}});
 const FR=[.1,.25,.5,.75];
 for(let t=0;t<N;t++){
  ST.randomizeSwings(); ST.recomputeSimulation(); await new Promise(r=>setTimeout(r,60));
  S.order=window.__ED_ORDERFN(S);
  const codes=Object.keys(S.simMuni), agg={}; let tot=0; codes.forEach(c=>{const m=S.simMuni[c];tot+=m.total_votes;for(const k in m.votes)agg[k]=(agg[k]||0)+m.votes[k];});
  const fin=U.allocateSeats(agg,tot,U.SEAT_TOTAL,U.THRESHOLD_PCT), win=Object.keys(agg).sort((a,b)=>agg[b]-agg[a])[0];
  const gov=['smer_sd','hlas_sd','sns'].reduce((a,x)=>a+(fin[x]||0),0)>=76, opp=['ps','demokrati','sas','kdh','olano_a_priatelia_ku_a_za_ludi'].reduce((a,x)=>a+(fin[x]||0),0)>=76;
  for(const f of FR){ S.revealedSet=new Set(S.order.slice(0,Math.floor(f*S.order.length))); S.playbackState='running';
   for(const k of K){ window.__ED_PROJ_S=k; const r=window.__ED_EXT4.projCompute(300); if(!r) continue; const R=res[k];
    // first-place Brier over parties
    r.slugs.forEach(x=>{const o=x===win?1:0;R.brFirst+=(r.first[x]-o)**2;}); R.nf++;
    if(r.blocs.length==2){R.brBloc+=(r.blocs[0].p-(gov?1:0))**2+(r.blocs[1].p-(opp?1:0))**2;R.nb++;}
    Object.keys(r.seats).forEach(x=>{ if(r.first[x]<0.01&&!(fin[x]>0)) return; const a=r.seats[x]; if(a.hi-a.lo<0) return; const c=(fin[x]||0)>=a.lo&&(fin[x]||0)<=a.hi; const key=f; R.byF[key]=R.byF[key]||[0,0]; R.byF[key][0]+=c?1:0; R.byF[key][1]++; R.cov.t=(R.cov.t||0)+(c?1:0); R.n.t=(R.n.t||0)+1; });
   }}
  S.playbackState='idle';
 }
 return res;},{K,N,EL});
for(const k of K){const R=out[k];console.log('K='+k,'80% interval coverage',(R.cov.t/R.n.t*100).toFixed(1)+'%','n='+R.n.t,'byFrac',JSON.stringify(Object.fromEntries(Object.entries(R.byF).map(([f,v])=>[f,(v[0]/v[1]*100).toFixed(0)+'%']))),'BrierFirst',(R.brFirst/R.nf).toFixed(4),'BrierBloc',(R.brBloc/Math.max(1,R.nb)).toFixed(4));}
await b.close();})();
